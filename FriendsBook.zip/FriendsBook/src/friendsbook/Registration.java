package friendsbook;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class Registration {
    public static String Name="";
    public static void createNewFriendsBookAccount()
    {
        //declare the local varaibles
        String AccountID = "";
        String Password = "";
        String Gender="";
        String School="";
        String Birthday="";
        Scanner input = new Scanner(System.in);
        
        //prompt and input
        System.out.println("Please Create your own AccountID:");
        System.out.println("NOTE:The AccountID should contain atleast 1 letter, 1 digit and 1 special char{#,?,!,*}");
        AccountID = input.next();
                
        //Check wether AcountID length and validation
        while((AccountID != null) &&!AccountID.matches("(?=.*\\d)(?=.*[a-zA-Z])(?=.*[#?!*]).{3,10}")){
            System.out.println(" The AccountID should contain atleast 1 letter, 1 digit and 1 special char{#,?,!,*}");
            System.out.println("Please Create your own AccountID:");
            System.out.println("NOTE:The AccountID should contain atleast 1 letter, 1 digit and 1 special char{#,?,!,*}");
            AccountID = input.next();
            System.out.println();
        }
        
        System.out.println("Please enter a Password:");
        Password = input.next();
        
        //Checks whether the Password and accountid is same 
         while(AccountID.equals(Password) )
        {
            System.out.println(" The AccountID and Password should not match");
            System.out.println("Please enter a Password:");
            Password = input.next();
            System.out.println();
        }
        
        System.out.println("Please enter your Name:");
        Name = input.next();
        
        System.out.println("Please enter Gender:");
        Gender = input.next();
        
        System.out.println("Please Provide the School Name:");
        School = input.next();
        
        System.out.println("Please enter your Birthday:");
        Birthday = input.next();
        
        //database operation
        //define DB_URL
        
        final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        
        Connection conn=null;
        Statement st=null;
        ResultSet rs=null;
        
        try
        {
           conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
            //Create a Statement
            st=conn.createStatement();
            //do a query to make sure AccountID is not used
            rs=st.executeQuery("Select * from UserAccount where AccountID='"+AccountID+"'");
            if(rs.next()){
               System.out.println("Account creation failed!AccountID already exists");
               
            }
             else{
                 //insert a record into User Account
                 int r=st.executeUpdate("Insert into UserAccount values('"+AccountID+"','"+Password+"','"+Name+"','"+Gender+"','"+School+"','"+Birthday+"')");
                 System.out.println("Account creation sucessful!\n");
             }
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }
        finally
        {
            //close db
            try
            {
                conn.close();
                st.close();
                rs.close();
            }
            catch(Exception e)
            {
              e.printStackTrace();
            }
        }
        
        
//        public class Registration {
//    //declare the global varaibles
//        String AccountID = "";
//        String Password = "";
//        String Gender="";
//        String Name="";
//        String School="";
//        String Birthday="";
//
//    public String getAccountID() {
//        return AccountID;
//    }
//
//    public void setAccountID(String AccountID) {
//        this.AccountID = AccountID;
//    }
//
//    public String getPassword() {
//        return Password;
//    }
//
//    public void setPassword(String Password) {
//        this.Password = Password;
//    }
//
//    public String getGender() {
//        return Gender;
//    }
//
//    public void setGender(String Gender) {
//        this.Gender = Gender;
//    }
//
//    public String getName() {
//        return Name;
//    }
//
//    public void setName(String Name) {
//        this.Name = Name;
//    }
//
//    public String getSchool() {
//        return School;
//    }
//
//    public void setSchool(String School) {
//        this.School = School;
//    }
//
//    public String getBirthday() {
//        return Birthday;
//    }
//
//    public void setBirthday(String Birthday) {
//        this.Birthday = Birthday;
//    }
//
//    public Registration() {
//              
//        Scanner input = new Scanner(System.in);
//        
//        //prompt and input
//        System.out.println("Please enter your AccountID:");
//        AccountID = input.next();
//                
//        //Check wether AcountID length and validation
//        while((AccountID != null) &&!AccountID.matches("(?=.*\\d)(?=.*[a-zA-Z])(?=.*[#?!*]).{3,10}")){
//            System.out.println(" The AccountID should contain atleast 1 letter, 1 digit and 1 special char{#,?,!,*}");
//            System.out.println("Please enter your AccountID:");
//            AccountID = input.next();
//            System.out.println();
//        }
//        
//        System.out.println("Please enter a Password:");
//        Password = input.next();
//        
//        //Checks whether the Password and accountid is same 
//         while(AccountID.equals(Password) )
//        {
//            System.out.println(" The AccountID and Password should not match");
//            System.out.println("Please enter a Password:");
//            Password = input.next();
//            System.out.println();
//        }
//        
//        System.out.println("Please enter your Name:");
//        Name = input.next();
//        
//        System.out.println("Please enter Gender:");
//        Gender = input.next();
//        
//        System.out.println("Please Provide the School Name:");
//        School = input.next();
//        
//        System.out.println("Please enter your Birthday:");
//        Birthday = input.next();
//        
//        //database operation
//        //define DB_URL
//    }
    }
    
}
