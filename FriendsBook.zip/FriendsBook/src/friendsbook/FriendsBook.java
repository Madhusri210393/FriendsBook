/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package friendsbook;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author HP
 */
public class FriendsBook {

    /**
     * @param args the command line arguments
     */
    public static ArrayList<FriendsBook> allFriendsBook;
    
    public static void main(String[] args) {
        // TODO code application logic here
        //create the objects of the arrayList
        allFriendsBook = new ArrayList<FriendsBook>();
        
        //display the main menu and get the input
        Scanner input = new Scanner(System.in);
        String selection = "";
        
        while(!selection.equals("x")){
              //show the menu
            System.out.println();
            System.out.println("Please make your selection");
            System.out.println("1: Register an new FriendsBook account");
            System.out.println("2: Login to your FriendsBook account");
            System.out.println("x: To Exit");
            
            //get the input
            selection = input.nextLine();
            System.out.println();
            
            if(selection.equals("1"))
            {
                //open a new bank account
                Registration.createNewFriendsBookAccount();
            }
            else if(selection.equals("2"))
            {
                //go to online system
               new Login().loginFriendsBookAccount();                
            }
            else if(selection.equals("x"))
            {
                //go out;
            }
        }
        
    }
    
}
