/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package friendsbook;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 *
 * @author HP
 */
public class Login {
    
        public static String AccountID="";
    public static void loginFriendsBookAccount()
    {
        //AccountID and Password to login
        Scanner input = new Scanner(System.in);
        String Password="";
        String Selection="";
        boolean idFound = false;
        
        //get the login info.
        System.out.println("Please enter your AccountID");
        AccountID = input.next();
        System.out.println("Please enter your Password");
        Password = input.next();
        
        
        //access the database and then login
        final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        
        Connection conn=null;
        Statement st=null;
        ResultSet rs=null;
        
        try
        {
           conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
            //Create a Statement
            st=conn.createStatement();
            //do a query to make sure Accountid and pasword is found
            rs=st.executeQuery("Select * from UserAccount where AccountID='"+AccountID+"'and Password='"+Password+"'");
            if(rs.next()){
                System.out.println();
                System.out.println("FriendsBook");
                System.out.println("-----Home Page-----");
                System.out.println();
               System.out.println("Welcome "+AccountID);
               UserTimeline.Menu();
            }
            else
            {
               System.out.println("loginNotOK");
                 
            }
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }
        finally
        {
            //close db
            try
            {
                conn.close();
                st.close();
                rs.close();
            }
            catch(Exception e)
            {
              e.printStackTrace();
            }
        }
    }
}
