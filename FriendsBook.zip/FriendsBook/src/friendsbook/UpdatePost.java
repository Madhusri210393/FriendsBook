/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package friendsbook;

/**
 *
 * @author HP
 */
public class UpdatePost {
   private String UPID;
   private String UserID;
   private String Type;
   private String Content;
   private String Date;

    public UpdatePost(String UPID, String UserID, String Type, String Content, String Date) {
        this.UPID = UPID;
        this.UserID = UserID;
        this.Type = Type;
        this.Content = Content;
        this.Date = Date;
    }

    public String getUPID() {
        return UPID;
    }

    public void setUPID(String UPID) {
        this.UPID = UPID;
    }

    public String getUserID() {
        return UserID;
    }

    public void setUserID(String UserID) {
        this.UserID = UserID;
    }

    public String getType() {
        return Type;
    }

    public void setType(String Type) {
        this.Type = Type;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String Content) {
        this.Content = Content;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }
   
   
}
