/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package friendsbook;

import static friendsbook.Login.AccountID;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author HP
 */
public class Count {
    public static int total=0;
    public static int Counting(){
        //access the database and then login
        final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        total=0;
        Connection conn=null;
        Statement st1=null;
        ResultSet rs1=null;        
        try
        {
             conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
            //Create a Statement
            st1=conn.createStatement();
            //do a query to make sure Accountid and pasword is found
            rs1=st1.executeQuery("Select * from Notification where Receiver='"+AccountID+"'"+"and Status='Pending'");
            while(rs1.next()){
                total++;
            }
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }
        finally
        {
            //close db
            try
            {
                conn.close();
                st1.close();
                rs1.close();
            }
            catch(Exception e)
            {
              e.printStackTrace();
            }
        }
        return total;
    }
}
