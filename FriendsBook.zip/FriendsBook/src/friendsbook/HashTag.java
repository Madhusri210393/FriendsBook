/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package friendsbook;

/**
 *
 * @author HP
 */
public class HashTag {
    private String Hash;
    private int Count;

    public HashTag(String Hash, int Count) {
        this.Hash = Hash;
        this.Count = Count;
    }

    public String getHash() {
        return Hash;
    }

    public void setHash(String Hash) {
        this.Hash = Hash;
    }

    public int getCount() {
        return Count;
    }

    public void setCount(int Count) {
        this.Count = Count;
    }
    
    
}
