/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package friendsbook;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author HP
 */
public class UserTimeline {
    private static int co=0;
    public static void Menu(){
        Scanner input = new Scanner(System.in);
        String Selection="";
        while(!Selection.equals("x")){
            co=new Count().Counting();
                               System.out.println();
                   System.out.println("Please make your selection");
                   System.out.println("1: Select an Update and Post");
                   System.out.println("2: Check Notification("+co+" new)");
                   System.out.println("3: Create a new Post");
                   System.out.println("4: Friends");
                   System.out.println("5: Update Profile");
                   System.out.println("6: Send a message");
                   System.out.println("7: Send a friend Request");
                   System.out.println("8: See Hastag in trend");
                   System.out.println("x: Logout");
                   
                   Selection = input.nextLine();
                   System.out.println();
                   
                   if(Selection.equals("1"))
                   {
                      UpdateAndPost();
                   }
                   else if(Selection.equals("2"))
                   {
                       Notification();
                   }
                   else if(Selection.equals("3"))
                   {
                       Post();
                   }
                   else if(Selection.equals("4"))
                   {
                       Friends();
                   }
                   else if(Selection.equals("5"))
                   {
                       UpdateProfile();
                   }
                   else if(Selection.equals("6"))
                   {
                       Message();
                   }
                   else if(Selection.equals("7"))
                   {
                       FriendRequest();
                   }
                   else if(Selection.equals("8"))
                   {
                       Hashtag();
                   }
                   else{
                       //
                   }
        }
    }
    public static void UpdateAndPost()
    {
        Login User=new Login();
        ArrayList<Comments>com=new ArrayList<Comments>();
        ArrayList<UpdatePost>UP=new ArrayList<UpdatePost>();
        ArrayList<Friends>Fri=new ArrayList<Friends>();
        Scanner input = new Scanner(System.in);
        String Selection="";
        
        //To search if User Notifications In Notification Database
           final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        
        Connection conn=null;
        Statement st=null;
        ResultSet rs=null;
        Statement st1=null;
        ResultSet rs1=null;
        Statement st2=null;
        ResultSet rs2=null;
        int count=1;
        String inp="";
        boolean found=false;
          try
            {
                conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673"); 
                //Create a Statement
                st=conn.createStatement();
                st1=conn.createStatement();
                st2=conn.createStatement();
                
                //do a query to find friends from Friends
                rs2=st2.executeQuery("Select * from Friends where UserID1='"+User.AccountID+"'"+"or UserID2='"+User.AccountID+"'");
                //ArrayList for Friends
                while (rs2.next())
                {
                  Friends fr=new Friends(rs2.getString("UserID1"),rs2.getString("UserID2"));
                    Fri.add(fr);
                }
                
                //do a query to find Updates and posts from UpdatePost
                rs1=st1.executeQuery("Select * from Update_Post order by UPID desc");
                //ArrayList for UpdatePost
                while (rs1.next())
                {
                   for(Friends fri:Fri){
                       if(rs1.getString("UserID").equals(fri.getUser1())||rs1.getString("UserID").equals(fri.getUser2())){
                        UpdatePost UPo=new UpdatePost(rs1.getString("UPID"),rs1.getString("UserID"),rs1.getString("Type"),rs1.getString("Content"),rs1.getString("Date_Time"));
                        UP.add(UPo);
                        //System.out.println(rs1.getString("UserID"));
                       }
                   }
                }
                
                //do a query to find Comments from Comments
                rs=st.executeQuery("Select * from Comments");
                while (rs.next())
                {
                  Comments Com=new Comments(rs.getString("UserID"),rs.getString("UPID"),rs.getString("Content"),rs.getString("Date"));
                    com.add(Com);
                }
                
                for(UpdatePost UPs:UP){
                    if(!UPs.getUserID().equals(User.AccountID)&& count<=3){
                        System.out.println("UPID:"+UPs.getUPID()+" FriendID:"+UPs.getUserID()+" Date and Time:"+UPs.getDate());
                        System.out.println("  POST:"+UPs.getContent());
                        System.out.println("    -----------------------------    ");
                        count++;
                        found=true;
                    }
                }
                count=1;
                if(found){
                     System.out.println();
                     System.out.println("Please enter an UPID to View or write a comment for the post or press 'x' to go back!!");
                     Selection=input.nextLine();
                     if(!Selection.equals("x")){
                         System.out.println("*****POST*****");
                          for(UpdatePost UPs:UP){
                              if(UPs.getUPID().equals(Selection)){
                                   System.out.println(UPs.getContent());
                                   System.out.println();
                                }
                              }
                          System.out.println("*****Comments*****");
                         for(Comments co:com){
                             if(co.getUPid().equals(Selection)){
                                 System.out.println("*"+co.getUser());
                                 System.out.println("COMMENT: "+co.getContent());
                                 System.out.println(" "+co.getDate());
                                 System.out.println("---------------");
                             }
                         }
                         System.out.println();
                         System.out.println("Write a Comment or press x!!");
                         inp=input.nextLine();
                         if(inp.equals("x")){
                             //
                         }
                         else{
                         int a=st.executeUpdate("Insert into Comments values('"+User.AccountID+"','"+Selection+"','"+inp+"','"+DateAndTime.DateTime()+"')");
                         System.out.println("Comment Has been sent!!");
                         System.out.println();
                         UpdateAndPost();
                         }
                     }
                     else if(Selection.equals("x")){
                         //go back;
                     }
                }
                else{
                    System.out.println("Oops!! Your have no post!!");
                }
            }
             catch(SQLException e)
             {
            e.printStackTrace();
             }
            finally
            {
                //close db
                try
                {
                    conn.close();
                    st.close();
                    rs.close();
                    st1.close();
                    rs1.close();
                    st2.close();
                    rs2.close();
                }
                catch(Exception e)
                {
                  e.printStackTrace();
                }
            }
        
        
    }
    public static void Notification()
    {
        co=new Count().Counting();

         Login User=new Login();
        Scanner input = new Scanner(System.in);
        String Selection="";
        String opt="";

        ArrayList<Notification>noti=new ArrayList<Notification>();
        //To search if User Notifications In Notification Database
           final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        
        Connection conn=null;
        Statement st=null;
         ResultSet rs=null;
         boolean found=false;
          try
        {
                conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673"); 
                //Create a Statement
                st=conn.createStatement();
                //do a query to find notifications from notification
                rs=st.executeQuery("Select * from Notification where Receiver='"+User.AccountID+"'"+"and Status='Pending'");
                while (rs.next())
                {
                  Notification note=new Notification(rs.getString("NotID"),rs.getString("Sender"),rs.getString("Type"),rs.getString("Content"),rs.getString("Status"));
                    noti.add(note);
                    found=true;
                }
                
                if(found){
                    System.out.println("-----NOTIFICATIONS-----");
                    for(Notification notif:noti){
                    System.out.println("ID:"+notif.getNid()+" Name:"+notif.getSender()+" Type: "+notif.getType()+" Context: "+notif.getContent()+" Status:"+notif.getStatus());
                }
                    System.out.println();
                System.out.println("Make a Selection");
                System.out.println("1: Accept");
                System.out.println("2: Reject");
                System.out.println("x: Go Back");
                Selection = input.nextLine();
                
                if(Selection.equals("1")){
                    System.out.println();
                    System.out.println("Enter the Notification ID you want to Accept");
                    opt=input.nextLine();
                    System.out.println();
                    
                    for(Notification notif:noti){
                        if(notif.getNid().equals(opt)&& notif.getType().equals("Friend Request")){
                            int a=st.executeUpdate("Update Notification set Status='Accepted',Content='Connected' where Receiver='"+User.AccountID+"' and NotID='"+opt+"'");
                        int b=st.executeUpdate("Insert into Friends values('"+User.AccountID+"','"+notif.getSender()+"')");
                        System.out.println("Your are now connected with "+notif.getSender());
                        }
                        else if(notif.getNid().equals(opt)&& notif.getType().equals("Message")){
                            int a=st.executeUpdate("Update Notification set Status='Accepted' where Receiver='"+User.AccountID+"' and NotID='"+opt+"'");
                        System.out.println(notif.getContent());
                        System.out.println("1: Reply");
                        String sel=input.nextLine();
                        if(sel.equals("1"))
                        {
                            Message();
                        }
                        else
                        {
                            st.executeUpdate("Update Notification set Status='Pending' where Receiver='"+User.AccountID+"' and NotID='"+opt+"'");
                            System.out.println("Invalid Selection");
                        }
                        }
                    }
                }
                else if(Selection.equals("2"))
                {
                    System.out.println("Enter the Notification ID you want to Reject");
                    opt=input.nextLine();
                        
                        int a=st.executeUpdate("Update Notification set Status='Rejected' where NotID='"+opt+"'");
                        System.out.println("You Have Rejected the Notification");
                }
                else if(Selection.equals("x"))
                {
                    //                
                }
                else
                {
                    System.out.println("Invalid Selection");
                }
        
        }
                else{
                    System.out.println("Hurray!! You Have no New Notifications");
                }
        }
          catch(SQLException e)
        {
            e.printStackTrace();
        }
        finally
        {
            //close db
            try
            {
                conn.close();
                st.close();
                rs.close();
            }
            catch(Exception e)
            {
              e.printStackTrace();
            }
        }
    }
    public static void Post()
    {
        Login User=new Login();
        //access the database and then login
        final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(Exception e)
        {
            System.out.println("Internal Error. Please Try It Again");
        }
        
        Connection conn=null;
        Statement st=null;
        ResultSet rs=null;
        Statement st1=null;
        ResultSet rs1=null;
        Scanner input = new Scanner(System.in);
        int upID=0;
        
        try
        {
        conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
        //Create a Statement
        st=conn.createStatement();
        st1=conn.createStatement();
        ArrayList<HashTag>HT=new ArrayList<HashTag>();
        
                //do a query to find friends from Friends
                rs1=st1.executeQuery("Select * from HashTag");
                //ArrayList for Friends
                while (rs1.next())
                {
                  HashTag Has=new HashTag(rs1.getString("Hashtag"),rs1.getInt("Count"));
                    HT.add(Has);
                }
        
        //To get the updateAndPost ID
            rs=st.executeQuery("Select *from upnum");
            int nextNum=0;
            //update the nextupdateAndPost Number
            if(rs.next())
            {
               upID=0+rs.getInt(1);
               nextNum=rs.getInt(1)+1;
            }
             System.out.println("-----Create A Post-----");
            System.out.println("What's on your Mind, "+User.AccountID+"           'x'-Close");
            String post=input.nextLine();
            post+=" ";
            int count=1;
            boolean found=false;
            if(!post.equals("x")){
                if(post.contains("#")){
                    int ash=post.indexOf("#");
            int space=post.indexOf(" ", ash);
            char[] has=post.toCharArray();
            String word="";

            for(int i=ash;i<space;i++){
                word+=has[i];
            }
            
            //checking whether the hashtag is present in the table
            for(HashTag Has:HT){
                if(Has.getHash().equals(word.toLowerCase())){
                    count=Has.getCount();
                    count++;
                    found=true;
                }
            }
            if(found){
                //System.out.println(count+" "+word);
            int a=st.executeUpdate("Update HashTag set Count='"+count+"' where Hashtag='"+word.toLowerCase()+"'");
            }
            else{
                //System.out.println(count+" "+word);
             int a=st.executeUpdate("Insert into HashTag values('"+word.toLowerCase()+"','"+count+"')");
            }
            }
              //updates the next_id
              int t=st.executeUpdate("Update upnum set next_id='"+nextNum+"'");
              //instert into Update_Post table
              int a=st.executeUpdate("Insert into update_post values('"+upID+"','"+User.AccountID+"','"+"Post"+"','"+post+"','"+DateAndTime.DateTime()+"')");
              System.out.println("The post is successful!!");
            }
            else if(post.equals("x")){
                //Go back
            }
              
        }
        catch(SQLException e)
            {
               e.printStackTrace();
            }
            finally
            {
            //close db
               try
               {
                conn.close();
                st.close();
                rs.close();
                st1.close();
                rs1.close();
               }
               catch(Exception e)
               {
                 e.printStackTrace();
               }
            } 
        
    }
    public static void Friends()
    {
        Login User=new Login();
        //access the database and then login
        final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        
        Connection conn=null;
        Connection conn1=null;
        Statement st=null;
        ResultSet rs=null;
        Statement st1=null;
        ResultSet rs1=null;
        Scanner input = new Scanner(System.in);
        boolean found=false;
        
        try
        {
            System.out.println("-----FRIENDS-----");
            System.out.println();
           conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
           conn1=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
            //Create a Statement
            st=conn.createStatement();
            st1=conn1.createStatement();
            //do a query to Find the Users Friends
            rs=st.executeQuery("Select * from Friends where UserID1='"+User.AccountID+"'or UserID2='"+User.AccountID+"'");

            //Print all of the users friend
            while(rs.next()){
                String User1=rs.getString("UserID1");
                String User2=rs.getString("UserID2");
                
                if(User1.equals(User.AccountID)){
                    System.out.println(User2+"  Friends");
                    found=true;
                }
                if(User2.equals(User.AccountID)){
                    System.out.println(User1+"  Friends");
                    found=true;
                }
               
            }
            if(found){
            //Taking input from the user to dispaly any friends profile info
            System.out.println();
            System.out.println("Please Enter friend's AccountID to see their Profile");
            String Selection=input.nextLine();
            
            try{
                //do a query to get all the info from UserAccount table
                rs1=st1.executeQuery("Select * from UserAccount where AccountID='"+Selection+"'");
                if(rs1.next())
                {
                String id=rs1.getString("AccountID");
                String name=rs1.getString("Name");
                String gender=rs1.getString("Gender");
                String School=rs1.getString("School");
                String bod=rs1.getString("Birthday");
                
                System.out.println();
                System.out.println("Name:"+name);
                System.out.println("AccountID:"+id);
                System.out.println("Gender:"+gender);
                System.out.println("School:"+School);
                System.out.println("Birthday:"+bod);
                
                System.out.println();
                System.out.println("Please press '2' to go Main Menu");
                String Slection=input.nextLine();
                    if(Selection.equals("2"))
                    {
                        //
                    }
                }
            }
            catch(SQLException e)
            {
           e.printStackTrace();
            }
            finally
            {
            //close db
               try
               {
                conn1.close();
                st1.close();
                rs1.close();
               }
               catch(Exception e)
               {
                 e.printStackTrace();
               }
            }
            }
            else if(!found){
                System.out.println("Oops!!You have no friend.         'x'-Close");
                System.out.println();
                System.out.println("To send a friend request press '1'");
                String ip=input.nextLine();
                if(ip.equals("1")){
                    FriendRequest();
                }
                else if(ip.equals("x")){
                    //go back
                }
            }
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }
        finally
        {
            //close db
            try
            {
                conn.close();
                st.close();
                rs.close();
            }
            catch(Exception e)
            {
              e.printStackTrace();
            }
        }
    }
    public static void UpdateProfile()
    {
        Scanner input = new Scanner(System.in);
        Login User=new Login();
        int UPID=0;
        //access the database and then login
        final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        
        Connection conn=null;
        Statement st=null;
        ResultSet rs=null;
        Statement st1=null;
        ResultSet rs1=null;
         Statement st2=null;
        ResultSet re=null;

        try
        {
           conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
            //Create a Statement
            st=conn.createStatement();
            st1=conn.createStatement();
            st2=conn.createStatement();
            
            re=st2.executeQuery("Select *from upnum");
            int nextNum=0;
            //update the nextUpdatepost Number
            if(re.next())
            {
               UPID=0+re.getInt(1);
               nextNum=re.getInt(1)+1;
            }
            
            //do a query to make sure Accountid and pasword is found
            rs=st.executeQuery("Select * from UserAccount where AccountID='"+User.AccountID+"'");
            if(rs.next()){
                String AccID=rs.getString("AccountID");
                String Pswd=rs.getString("Password");
                String Name=rs.getString("Name");
                String Gender=rs.getString("Gender");
                String School=rs.getString("School");
                String Birthday=rs.getString("Birthday");
                System.out.println("1:AccountID:"+AccID);
                System.out.println("2:Password:"+Pswd);
                System.out.println("3:Name:"+Name);
                System.out.println("4:Gender:"+Gender);
                System.out.println("5:School:"+School);
                System.out.println("6:Birthday:"+Birthday);
                System.out.println("7:Go back");
                System.out.println();
                System.out.println("Please make Your Selection to Update!!");
                String opt=input.nextLine();
                System.out.println();
                
                if(opt.equals("1"))
                {
                    System.out.println("Please enter your new AccountID");
                    String acc=input.nextLine();
                    
                    if(acc.equals(AccID))
                    {
                        System.out.println("Current AccountID and new AccountID are both the same!!");
                    }
                    else
                    {
                    //Check wether AcountID length and validation
                       while((acc != null) &&!acc.matches("(?=.*\\d)(?=.*[a-zA-Z])(?=.*[#?!*]).{3,10}")){
                        System.out.println(" The AccountID should contain atleast 1 letter, 1 digit and 1 special char{#,?,!,*}");
                        System.out.println("Please enter your new AccountID:");
                        acc= input.next();
                        }
                       
                       rs1=st1.executeQuery("Select * from UserAccount where AccountID='"+acc+"'");
                       if(rs1.next()){
                       System.out.println("Account creation failed!AccountID already exists");

                       }
                       else if(!rs1.next())
                       {
                           //insert a record into User Account
                         int a=st.executeUpdate("Update UserAccount set AccountID='"+acc+"' where AccountID='"+AccID+"'");
                         int b=st.executeUpdate("Update Friends set UserID1='"+acc+"' where UserID1='"+AccID+"'");
                         int c=st.executeUpdate("Update Friends set UserID2='"+acc+"' where UserID2='"+AccID+"'");
                         int d=st1.executeUpdate("Update Notification set Sender='"+acc+"' where Sender='"+AccID+"'");
                         int e=st1.executeUpdate("Update Notification set Receiver='"+acc+"' where Receiver='"+AccID+"'");
                         System.out.println();
                         System.out.println("AccountID Update sucessful!!Please login Again.");
                         new Login().loginFriendsBookAccount();
                         System.out.println();
                       }
                    }
                    st1.close();
                    rs1.close();
                }
                else if(opt.equals("2"))
                {
                    System.out.println("Please enter your Old Password");
                    String old=input.nextLine();
                    System.out.println("Please enter your new Password");
                    String acc=input.nextLine();
                    
                    if(old.equals(Pswd))
                    {
                        if(!old.equals(acc))
                        {
                         st.executeUpdate("Update UserAccount set Password='"+acc+"' where AccountID='"+AccID+"'");
                         System.out.println("Password Update sucessful!!");
                         System.out.println();
                        }
                        else
                        {
                            System.out.println("Current password and new password are both the same!!");
                        }
                    }
                    else
                    {
                        System.out.println("Please enter your correct Current password!!");
                    }
                }
                else if(opt.equals("3"))
                {
                    System.out.println("Please enter your Name");
                    String nam=input.nextLine();
                    
                    int t=st2.executeUpdate("Update upnum set Next_id='"+nextNum+"'");
                        //instert into Notification table
                        int a=st.executeUpdate("Insert into update_post values('"+UPID+"','"+User.AccountID+"','"+"Update"+"','"+User.AccountID+" updated thier name"+"','"+DateAndTime.DateTime()+"')");
                    
                    st.executeUpdate("Update UserAccount set Name='"+nam+"' where AccountID='"+AccID+"'");
                    System.out.println("Name Update sucessful!!");
                    System.out.println();
                }
                else if(opt.equals("4"))
                {
                    System.out.println("Please enter your Gender");
                    String gen=input.nextLine();
                    
                    st.executeUpdate("Update UserAccount set Gender='"+gen+"' where AccountID='"+AccID+"'");
                     int t=st2.executeUpdate("Update upnum set Next_id='"+nextNum+"'");
                        //instert into Notification table
                        int a=st.executeUpdate("Insert into update_post values('"+UPID+"','"+User.AccountID+"','"+"Update"+"','"+User.AccountID+" updated thier Gender"+"','"+DateAndTime.DateTime()+"')");
                    System.out.println("Gender Update sucessful!!");
                    System.out.println();
                }
                else if(opt.equals("5"))
                {
                    System.out.println("Please enter your School");
                    String sch=input.nextLine();
                    
                    st.executeUpdate("Update UserAccount set School='"+sch+"' where AccountID='"+AccID+"'");
                     int t=st2.executeUpdate("Update upnum set Next_id='"+nextNum+"'");
                        //instert into Notification table
                        int a=st.executeUpdate("Insert into update_post values('"+UPID+"','"+User.AccountID+"','"+"Update"+"','"+User.AccountID+" updated thier School"+"','"+DateAndTime.DateTime()+"')");
                    System.out.println("School Update sucessful!!");
                    System.out.println();
                }
                else if(opt.equals("6"))
                {
                    System.out.println("Please enter your Birthday");
                    String bod=input.nextLine();
                    
                    st.executeUpdate("Update UserAccount set Gender='"+bod+"' where AccountID='"+AccID+"'");
                     int t=st2.executeUpdate("Update upnum set Next_id='"+nextNum+"'");
                        //instert into Notification table
                        int a=st.executeUpdate("Insert into update_post values('"+UPID+"','"+User.AccountID+"','"+"Update"+"','"+User.AccountID+" updated thier birthday"+"','"+DateAndTime.DateTime()+"')");
                    System.out.println("Bithday Update sucessful!!");
                    System.out.println();
                }
                else if(opt.equals("7")){
                    //
                }
                
            }
            
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }
        finally
        {
            //close db
            try
            {
                conn.close();
                st.close();
                rs.close();
                
            }
            catch(Exception e)
            {
              e.printStackTrace();
            }
        }
    }
     public static void Message()
    {
        Login User=new Login();
        int NotID=0;

        Scanner input = new Scanner(System.in);
        System.out.println();
        System.out.println("Enter Your friends AccountID To send a Message.");
        String FriendID=input.nextLine();
        
        //To search the Friends ID in UserAccount Database
        final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        
        Connection conn=null;
        Statement st=null;
        Statement st1=null;
        
        ResultSet rs=null;
        ResultSet re=null;
        
        
        try
        {
           conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
            //Create a Statement
            st=conn.createStatement();
            st1=conn.createStatement();
            
            //do a query to make sure User and the FriendID are friends.
            re=st1.executeQuery("Select * from Friends where (UserID1='"+User.AccountID+"' and UserID2='"+FriendID+"')or(UserID1='"+FriendID+"' and UserID2='"+User.AccountID+"')");
            //To get the Notification ID
            rs=st.executeQuery("Select *from nextnot");
            int nextNum=0;
            //update the nextNotification Number
            if(rs.next())
            {
               NotID=0+rs.getInt(1);
               nextNum=rs.getInt(1)+1;
            }
            String send="";
            if(re.next()){
                Statement st2=null;
                ResultSet rs1=null;
                st2=conn.createStatement();
                //do a query to Find Messages realted to userAccount
                rs1=st2.executeQuery("Select * from Notification where (Receiver='"+FriendID+"' and Sender='"+User.AccountID+"') or (Receiver='"+User.AccountID+"'and Sender='"+FriendID+"')");

                System.out.println();
                    while(rs1.next())
                    {
                      String msg=rs1.getString("Content");
                      String Sen=rs1.getString("Sender");
                      String ty=rs1.getString("Type");
                      if(ty.equals("Message")){
                          if(!Sen.equals(User.AccountID)){
                          System.out.println(Sen+": "+msg);
                          }
                          else{
                          System.out.println("                            You: "+msg);
                          }
                      }
                    }

                    System.out.println();
                    System.out.println("Please type Your message or Press 'Enter' for cancel option!!");
                    String Reply=input.nextLine();
                    System.out.println("press '1' to send or '2' cancel !!");
                    send=input.nextLine();
                    if(send.equals("1"))
                    {
                        //updates the next_id
                        int t=st.executeUpdate("Update nextnot set Next_id='"+nextNum+"'");
                        //instert into Notification table
                        int a=st.executeUpdate("Insert into Notification values('"+NotID+"','"+User.AccountID+"','"+FriendID+"','"+"Message"+"','"+Reply+"','"+"Pending"+"')");
                        System.out.println("The message has been sent to "+FriendID);
                    }
                    else if(send.equals("2")){
                        //get out
                    }
                    rs1.close();
                    st2.close();
            }
            else
            {
               System.out.printf("%s is not your friend!!",FriendID);
                 
            }
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }
        finally
        {
            //close db
            try
            {
                conn.close();
                st.close();
                rs.close();
                st1.close();
                re.close();
                
            }
            catch(Exception e)
            {
              e.printStackTrace();
            }
        }
    }
     
    public static void FriendRequest()
    {
        Login User=new Login();
        int NotID=0;
        
        //Entering Fiends ID to Send them Request
        Scanner input = new Scanner(System.in);
        System.out.println("Enter Your friends AccountID To send a request.");
        String FriendID=input.nextLine();
        
        //To search the Friends ID in UserAccount Database
        final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        
        Connection conn=null;
        Statement st=null;
        Statement st1=null;
        Statement st2=null;
        ResultSet rs=null;
        ResultSet re=null;
        ResultSet rs1=null;
        
        try
        {
           conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
            //Create a Statement
            st=conn.createStatement();
            st1=conn.createStatement();
            st2=conn.createStatement();
            //do a query to make sure Accountid is found
            re=st1.executeQuery("Select * from UserAccount where AccountID='"+FriendID+"'");
           
            //To get the Notification ID
            rs=st.executeQuery("Select *from nextnot");
            int nextNum=0;
            //update the nextNotification Number
            if(rs.next())
            {
               NotID=0+rs.getInt(1);
               nextNum=rs.getInt(1)+1;
            }
            //Check if they are already friends
            rs1=st2.executeQuery("Select * from Friends where (UserID1='"+FriendID+"' and USerID2='"+User.AccountID+"') or (UserID1='"+User.AccountID+"' and UserID2='"+FriendID+"')");
            if(re.next()){
                
                if(rs1.next()){
                System.out.println("Your are already friends");
                }
                else if(!rs1.next()){
                //updates the next_id
                int t=st.executeUpdate("Update nextnot set Next_id='"+nextNum+"'");
                //instert into Notification table
               int r=st.executeUpdate("Insert into Notification values('"+NotID+"','"+User.AccountID+"','"+FriendID+"','"+"Friend Request"+"','"+"You Have New Friend Request"+"','"+"Pending"+"')");
               System.out.println("A request is sent to "+FriendID);
                }
            }
            else
            {
               System.out.println("FriendID Not Found");
                 
            }
        }
        catch(SQLException e)
        {
           e.printStackTrace();
        }
        finally
        {
            //close db
            try
            {
                conn.close();
                st.close();
                rs.close();
                st1.close();
                re.close();
                rs1.close();
                st2.close();
            }
            catch(Exception e)
            {
              e.printStackTrace();
            }
        }
    }
    public static void Hashtag()
    {
        Login User=new Login();
        //To search the Friends ID in UserAccount Database
        final String DB_URL="jdbc:mysql://mis-sql.uhcl.edu/madhusrisidd156";
        
        Connection conn=null;
        Statement st=null;
        ResultSet rs=null;
        Statement st1=null;
        ResultSet rs1=null;
         Statement st2=null;
        ResultSet rs2=null;
         Statement st3=null;
        ResultSet rs3=null;
        Scanner input = new Scanner(System.in);
        String Selection="";
        int count=1;
        boolean found=false;
        boolean hashfound=false;
        int intIndex=-1;
        
         try
        {
           conn=DriverManager.getConnection(DB_URL,"madhusrisidd156","1654673");
            //Create a Statement
            st=conn.createStatement();
            st1=conn.createStatement();
            st2=conn.createStatement();
            st3=conn.createStatement();
            
            ArrayList<HashTag>Has=new ArrayList<HashTag>();
            ArrayList<Comments>com=new ArrayList<Comments>();
            ArrayList<UpdatePost>UP=new ArrayList<UpdatePost>();
            ArrayList<Friends>Fri=new ArrayList<Friends>();
            
            //do a query to dsplay all the Hashtas
            rs=st.executeQuery("Select * from HashTag order by Count desc");
            while(rs.next()){
                HashTag HT=new HashTag(rs.getString("Hashtag"),rs.getInt("Count"));
                Has.add(HT);
            }
        //do a query to find friends from Friends
            rs1=st1.executeQuery("Select * from Friends where UserID1='"+User.AccountID+"'"+"or UserID2='"+User.AccountID+"'");
            //ArrayList for Friends
            while (rs1.next())
            {
              Friends fr=new Friends(rs1.getString("UserID1"),rs1.getString("UserID2"));
                Fri.add(fr);
            }

            //do a query to find Updates and posts from UpdatePost
            rs2=st2.executeQuery("Select * from Update_Post order by UPID desc");
            //ArrayList for UpdatePost
            while (rs2.next())
            {
               for(Friends fri:Fri){
                   if(rs2.getString("UserID").equals(fri.getUser1())||rs2.getString("UserID").equals(fri.getUser2())){
                    UpdatePost UPo=new UpdatePost(rs2.getString("UPID"),rs2.getString("UserID"),rs2.getString("Type"),rs2.getString("Content"),rs2.getString("Date_Time"));
                    UP.add(UPo);
                   }
               }
            }

            //do a query to find Comments from Comments
            rs3=st3.executeQuery("Select * from Comments");
            while (rs3.next())
            {
              Comments Com=new Comments(rs3.getString("UserID"),rs3.getString("UPID"),rs3.getString("Content"),rs3.getString("Date"));
                com.add(Com);
            }
            System.out.println("-----Top 3 HashTag In Trend-----");
            for(HashTag ht:Has){
                if(count<=3){
                    System.out.println(ht.getHash());
                    System.out.println();
                    found=true;
                    count++;
                }
            }
            if(found){
            count=1;
            System.out.println("Select a HashTag or enter any Hastag to display the related post!");
            Selection=input.nextLine().toLowerCase();
            
                         
                for(UpdatePost UPs:UP){
                    if(!UPs.getUserID().equals(User.AccountID)){
                        String msg=UPs.getContent().toLowerCase();
                        int Ash=Selection.indexOf("#");
                        intIndex = msg.indexOf(Selection); 
                        if(intIndex!=-1&&Ash!=-1){
                            System.out.println();
                            System.out.println("Posts related to "+Selection.toUpperCase());
                            System.out.println("UPID:"+UPs.getUPID()+" FriendID:"+UPs.getUserID()+" Date and Time:"+UPs.getDate());
                            System.out.println("  POST:"+UPs.getContent());
                            System.out.println("    -----------------------------    ");
                            hashfound=true;
                        }
                        
                    }
                }
                if(hashfound){
             System.out.println();
             System.out.println("Please enter an UPID to View or write a comment for the post or press 'x' to go back!!");
             Selection=input.nextLine();
             if(!Selection.equals("x")){
                 System.out.println("*****POST*****");
                  for(UpdatePost UPs:UP){
                      if(UPs.getUPID().equals(Selection)){
                           System.out.println(UPs.getContent());
                           System.out.println();
                        }
                      }
                  System.out.println("*****Comments*****");
                 for(Comments co:com){
                     if(co.getUPid().equals(Selection)){
                         System.out.println("*"+co.getUser());
                         System.out.println("COMMENT: "+co.getContent());
                         System.out.println(" "+co.getDate());
                         System.out.println("---------------");
                        }
                     }
                 
                 System.out.println();
                 System.out.println("Write a Comment or press x!!");
                 String inp=input.nextLine();
                 if(inp.equals("x")){
                     //
                 }
                 else{
                 int a=st.executeUpdate("Insert into Comments values('"+User.AccountID+"','"+Selection+"','"+inp+"','"+DateAndTime.DateTime()+"')");
                 System.out.println("Comment Has been sent!!");
                 System.out.println();
                 }
                }
                }
                else if(!hashfound){
                    System.out.println();
                    System.out.println(Selection+" not found from your friends post!!");
                    System.out.println();
                }
            }
            else{
                System.out.println("Oops!!No Hashtag(s) found");
            }
        }
         catch(SQLException e)
        {
           e.printStackTrace();
        }
        finally
        {
            //close db
            try
            {
                conn.close();
                st.close();
                rs.close();
            }
            catch(Exception e)
            {
              e.printStackTrace();
            }
        }
        
    }
    
}
